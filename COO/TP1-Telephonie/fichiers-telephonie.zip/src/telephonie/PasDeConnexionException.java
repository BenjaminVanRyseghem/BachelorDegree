
package telephonie;


public class PasDeConnexionException extends Exception {

}
