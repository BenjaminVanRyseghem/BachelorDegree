
package telephonie;


public class OperateurSatureException extends Exception {
}
