
package telephonie;


public class ModeDePaiementInvalideException extends Exception {

}
