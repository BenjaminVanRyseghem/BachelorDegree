#include<stdio.h>
#include<stdlib.h>
#include"trBib.h"

int main(){
	tronque();
	return 0;
}
	
