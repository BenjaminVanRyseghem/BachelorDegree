void tronque();
