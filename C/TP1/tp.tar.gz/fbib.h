
unsigned int factorielle_recursive (unsigned int n);

unsigned int factorielle (unsigned int n);

unsigned int factorielle_iterative (unsigned int n);