#include<stdlib.h>
#include<stdio.h>
#include"fbib.h"

int main (){
	printf("%d\n",factorielle(10));
	return 0;
}
