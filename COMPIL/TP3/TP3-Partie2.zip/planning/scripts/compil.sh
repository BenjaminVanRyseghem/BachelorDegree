javac -d classes `ls */planningMaster/*/*.java`
