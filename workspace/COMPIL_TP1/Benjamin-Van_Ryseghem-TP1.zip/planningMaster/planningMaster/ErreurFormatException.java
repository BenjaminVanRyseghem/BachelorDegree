package planningMaster;

public class ErreurFormatException extends Exception {

	public static final long serialVersionUID = 1234554321;
   
	public ErreurFormatException(String msg) {
    	super(msg);
    }

}