package ressource;


public class RessourceInvalideException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6240790481737778778L;

}
