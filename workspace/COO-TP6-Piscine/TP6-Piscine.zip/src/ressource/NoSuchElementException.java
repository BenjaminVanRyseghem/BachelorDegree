package ressource;


public class NoSuchElementException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6000435210378134416L;

}
