package ressource;


public interface Ressource { 
	public String description();
}